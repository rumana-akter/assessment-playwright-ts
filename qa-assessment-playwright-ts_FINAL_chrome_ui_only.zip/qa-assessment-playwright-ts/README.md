# QA Automation Engineer Assessment – Playwright (TypeScript)

**Website:** https://practicesoftwaretesting.com/

This repository implements the **two required UI tests** using Playwright + TypeScript, following Page Object Model.

## Tasks Covered
1. **Contact Form Validation**
   - Submit empty → validation errors shown
   - Fill valid fields (First name, Last name, Email, Subject, Message) → submit → success message

2. **Add to Cart & Update**
   - Navigate to "Combination Pliers" product page
   - Add to cart
   - Open cart page
   - Verify product present
   - Update quantity to 3 and verify

## How to Run
```bash
npm install
npm run prepare
npm test        # runs Chrome UI tests
npm run report  # open HTML report
```

## Project Structure
```text
src/
  pages/         # Page Objects
  tests/ui/      # UI Tests
playwright.config.ts
package.json
README.md
```

## Notes
- Chrome only
- Strictly UI tests as per instructions
- Page Object Model for scalability
